<template>
  <div>
    <v-toolbar-title>About</v-toolbar-title>
  </div>
</template>

<script>
export default {
  name: "AboutToolbar"
};
</script>
