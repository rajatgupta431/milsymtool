<template>
  <div>
    <v-toolbar-title>Help</v-toolbar-title>
  </div>
</template>

<script>
export default {
  name: "HelpToolbar"
};
</script>
